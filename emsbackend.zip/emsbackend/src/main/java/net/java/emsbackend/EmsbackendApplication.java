package net.java.emsbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmsbackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmsbackendApplication.class, args);
	}

}
