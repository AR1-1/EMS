package net.java.emsbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmsbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
